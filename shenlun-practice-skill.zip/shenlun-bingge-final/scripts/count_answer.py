#!/usr/bin/env python3
"""Count non-whitespace characters; this is not an official answer-grid calculator."""
import argparse
import json
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('file', nargs='?', help='UTF-8 plain-text answer; omit to read stdin')
    parser.add_argument('--min', type=int, dest='minimum')
    parser.add_argument('--max', type=int, dest='maximum')
    args = parser.parse_args()
    if args.minimum is not None and args.minimum < 0:
        parser.error('--min must be nonnegative')
    if args.maximum is not None and args.maximum < 0:
        parser.error('--max must be nonnegative')
    if args.minimum is not None and args.maximum is not None and args.minimum > args.maximum:
        parser.error('--min must not exceed --max')
    content = Path(args.file).read_text(encoding='utf-8') if args.file else sys.stdin.read()
    count = sum(not c.isspace() for c in content)
    within = (args.minimum is None or count >= args.minimum) and (args.maximum is None or count <= args.maximum)
    print(json.dumps({
        'non_whitespace_characters': count,
        'minimum': args.minimum,
        'maximum': args.maximum,
        'within_bounds': within,
        'note': '包含标点与标题；请仅输入正式答案。非官方答题卡占格计算。'
    }, ensure_ascii=False))
    return 0 if within else 1


if __name__ == '__main__':
    sys.exit(main())
